import java.sql.Date;

public class Capacitacion {
  private double idInterno;
  private int rut;
  private Date dia;
  private String hora;
  private String lugar;
  private int duracion;
  private int cantAsistentes;
  @Override
  public String toString() {
    return "Capacitacion{" +
            "idInterno=" + idInterno +
            ", rut=" + rut +
            ", dia='" + dia + '\'' +
            ", hora='" + hora + '\'' +
            ", lugar='" + lugar + '\'' +
            ", duracion=" + duracion +
            ", cantAsistentes=" + cantAsistentes +
            '}';
  }
  public Capacitacion() {
  }
  public Capacitacion(double idInterno, int rut, Date dia, String hora,
                      String lugar, int duracion, int cantAsistentes) {
    this.idInterno = idInterno;
    this.rut = rut;
    this.dia = dia;
    this.hora = hora;
    this.lugar = lugar;
    this.duracion = duracion;
    this.cantAsistentes = cantAsistentes;
  }
}