import java.sql.Date;

public class Main {
  public static void main(String[] args) {

    Cliente cliente = new Cliente(99999999, "Benjamin andres", "Castro Ormeño",
            1231231, 4, "el alazan", "killpue", 123);
    System.out.println(cliente.toString());
    Capacitacion capacitacion = new Capacitacion(122.0 , 8282882,
            new Date(123,4,20),
            "12:30", "casa", 2, 22);
    System.out.println(capacitacion.toString());
    Usuario usuario = new Usuario("Pedro Diaz", new Date(106,11,01), 1999299);
    System.out.println(usuario.toString());
  }
}