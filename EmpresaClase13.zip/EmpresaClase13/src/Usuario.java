import java.sql.Date;

public class Usuario {
  private String nombre;
  private Date fechaDeNacimiento;
  private int run;

  public Usuario() {
  }

  public Usuario(String nombre, Date fechaDeNacimiento, int run) {
    this.nombre = nombre;
    this.fechaDeNacimiento = fechaDeNacimiento;
    this.run = run;
  }

  @Override
  public String toString() {
    return "Usuario{" +
            "nombre='" + nombre + '\'' +
            ", fechaDeNacimiento=" + fechaDeNacimiento +
            ", run=" + run +
            '}';
  }
}
