public class Cliente {

  private int rut;
  private String nombres;
  private String apellidos;
  private int telefono;
  private int sistemaDeSalud;
  public final int FONASA = 1;
  public final int ISAPRE = 2;
  private String direccion;
  private String comuna;
  private int edad;

  public Cliente() {
  }

  public Cliente(int rut, String nombres, String apellidos, int telefono,
                      int sistemaDeSalud, String direccion, String comuna, int edad) {
    this.nombres = nombres;
    this.apellidos = apellidos;
    this.telefono = telefono;
    this.direccion = direccion;
    this.comuna = comuna;
    this.edad = edad;
    if (comprobarSistemaDeSalud(sistemaDeSalud)) {
      this.sistemaDeSalud = sistemaDeSalud;
    }
    if (comprobarRut(rut)) {
      this.rut = rut;
    }
  }


  public boolean comprobarSistemaDeSalud(int sistemaDeSalud){
    return (sistemaDeSalud == 1 || sistemaDeSalud == 2);
  }
  public boolean comprobarRut(int rut){
    return (rut < 99999999);
  }

  @Override
  public String toString() {
    return "Cliente{" +
            "rut=" + rut +
            ", nombres='" + nombres + '\'' +
            ", apellidos='" + apellidos + '\'' +
            ", telefono=" + telefono +
            ", sistemaDeSalud=" + sistemaDeSalud +
            ", direccion='" + direccion + '\'' +
            ", comuna='" + comuna + '\'' +
            ", edad=" + edad +
            '}';
  }
}
