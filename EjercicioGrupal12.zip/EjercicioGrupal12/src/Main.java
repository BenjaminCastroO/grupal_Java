public class Main {
    public static void main(String[] args) {
        System.out.println("Ejercicio Grupal 12");
    }
}