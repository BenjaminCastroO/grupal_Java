import java.sql.Date;
import java.sql.Time;

public class Revision {
  public final int SIN_PROBLEMAS = 1;
  public final int CON_OBSERVACIONES = 2;
  public final int NO_APRUEBA = 3;

  private int idRevision;
  private String nombreRevision;
  private String detalleParaRevisar;
  private int estado;

  public Revision() {
  }

  public Revision(int idRevision, String nombreRevision, String detalleParaRevisar, int estado) {
    this.idRevision = idRevision;
    this.nombreRevision = nombreRevision;
    this.detalleParaRevisar = detalleParaRevisar;
    if (comprobarEstado(estado))
      this.estado = estado;
  }

  public int getIdRevision() {
    return idRevision;
  }

  public void setIdRevision(int idRevision) {
    this.idRevision = idRevision;
  }

  public String getNombreRevision() {
    return nombreRevision;
  }

  public void setNombreRevision(String nombreRevision) {
    this.nombreRevision = nombreRevision;
  }

  public String getDetalleParaRevisar() {
    return detalleParaRevisar;
  }

  public void setDetalleParaRevisar(String detalleParaRevisar) {
    this.detalleParaRevisar = detalleParaRevisar;
  }

  public int getEstado() {
    return estado;
  }

  public void setEstado(int estado) {
    this.estado = estado;
  }

  private boolean comprobarEstado(int estado){
    return (estado == SIN_PROBLEMAS || estado == CON_OBSERVACIONES || estado == NO_APRUEBA);
  }
  public String obtenerEstado() {
    if (estado == SIN_PROBLEMAS) return "SIN PROBLEMAS";
    if (estado == CON_OBSERVACIONES) return "CON OBSERVACIONES";
    if (estado == NO_APRUEBA) return "NO APRUEBA";
    else return "INVÁLIDO";
  }

}
