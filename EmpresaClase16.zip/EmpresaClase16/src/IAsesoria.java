public interface IAsesoria {

  public void analizarUsuario();

}
