import java.util.ArrayList;
import java.util.List;

public class Listado {
  private List<IAsesoria> listado = new ArrayList<IAsesoria>();

  public void addUsuario(IAsesoria usuario){
    listado.add(usuario);
  }

  public void analizarUsuarios(){
      for (IAsesoria usuario: listado) {
        usuario.analizarUsuario();
      }
  }
  public Listado() {
  }

  public Listado(List<IAsesoria> listado) {
    this.listado = listado;
  }
}
