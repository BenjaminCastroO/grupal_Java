import java.sql.Date;

public class Profesional extends Usuario{
  private String titulo;
  private Date fechaIngreso;

  public Profesional() {
  }

  public Profesional(String nombreUsuario, String titulo, Date fechaIngreso) {
    super.setNombre(nombreUsuario);
    this.titulo = titulo;
    this.fechaIngreso = fechaIngreso;
  }

  public String getTitulo() {
    return titulo;
  }

  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }

  public Date getFechaIngreso() {
    return fechaIngreso;
  }

  public void setFechaIngreso(Date fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

  @Override
  public String toString() {
    return "Profesional " +
            "titulo='" + titulo + '\'' +
            ", fechaIngreso=" + fechaIngreso +
            ' ';
  }
  @Override
  public void analizarUsuario() {
    super.analizarUsuario();
    System.out.println(this.toString());
  }
}
