import java.sql.Date;

public class Main {
  public static void main(String[] args) {

    Listado lista = new Listado();
    lista.addUsuario(new Cliente("benja", 9999999, "Benjamin andres", "Castro" +
            " Ormeño",
            1231231, "planvital", 2, "el alazan", "killpue", 23));
    lista.addUsuario(new Cliente("carlo", 11111111, "carlos andres", "flores " +
            "marx",
            1234567, "afp modelo", 1, "salvador", "santiago", 56));
    lista.addUsuario(new Administrativo("pedro","oficina", "tengo experiencia"));
    lista.addUsuario(new Profesional("Gonzalo","doctorado", new Date(96,11,6)));
    lista.addUsuario(new Administrativo("pablo", "rrhh", "tengo mucha " +
            "experiencia en administración"));



    lista.analizarUsuarios();



  }
}