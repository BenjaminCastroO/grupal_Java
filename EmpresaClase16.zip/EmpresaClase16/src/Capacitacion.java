import java.sql.Date;

public class Capacitacion {
  private double idInterno;
  private Date dia;
  private String hora;
  private String lugar;
  private int duracion;
  private int cantAsistentes;
  @Override
  public String toString() {
    return "Capacitacion{" +
            "idInterno=" + idInterno +
            ", dia='" + dia + '\'' +
            ", hora='" + hora + '\'' +
            ", lugar='" + lugar + '\'' +
            ", duracion=" + duracion +
            ", cantAsistentes=" + cantAsistentes +
            '}';
  }
  public Capacitacion() {
  }
  public Capacitacion(double idInterno, Date dia, String hora,
                      String lugar, int duracion, int cantAsistentes) {
    this.idInterno = idInterno;
    this.dia = dia;
    this.hora = hora;
    this.lugar = lugar;
    this.duracion = duracion;
    this.cantAsistentes = cantAsistentes;
  }

  public String mostrarDetalle(){
    String mensaje = "La capacitación será en " + lugar + " a las " + hora  +
            " del día " + dia + " y durará " + duracion + " minutos.";
    return mensaje;
  }

  public double getIdInterno() {
    return idInterno;
  }

  public void setIdInterno(double idInterno) {
    this.idInterno = idInterno;
  }

  public Date getDia() {
    return dia;
  }

  public void setDia(Date dia) {
    this.dia = dia;
  }

  public String getHora() {
    return hora;
  }

  public void setHora(String hora) {
    this.hora = hora;
  }

  public String getLugar() {
    return lugar;
  }

  public void setLugar(String lugar) {
    this.lugar = lugar;
  }

  public int getDuracion() {
    return duracion;
  }

  public void setDuracion(int duracion) {
    this.duracion = duracion;
  }

  public int getCantAsistentes() {
    return cantAsistentes;
  }

  public void setCantAsistentes(int cantAsistentes) {
    this.cantAsistentes = cantAsistentes;
  }
}