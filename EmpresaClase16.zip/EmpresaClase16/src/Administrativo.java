public class Administrativo extends Usuario{
  private String area;
  private String experiencia;

  public Administrativo() {
  }

  public Administrativo(String nombreUsuario, String area, String experiencia) {
    super.setNombre(nombreUsuario);
    this.area = area;
    this.experiencia = experiencia;
  }

  public String getArea() {
    return area;
  }

  public void setArea(String area) {
    this.area = area;
  }

  public String getExperiencia() {
    return experiencia;
  }

  public void setExperiencia(String experiencia) {
    this.experiencia = experiencia;
  }

  @Override
  public String toString() {
    return "Administrativo " +
            "area='" + area + '\'' +
            ", experiencia='" + experiencia + '\'' +
            ' ';
  }
  @Override
  public void analizarUsuario() {
    super.analizarUsuario();
    System.out.println(this.toString());
  }
}
