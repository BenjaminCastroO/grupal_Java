package interfaces;

//Responsabilidad única: esta interface solo se dedica a definir
// analizarUsuario para aquellas clases que la implementen.
public interface IAsesoria {

  public void analizarUsuario();

}
