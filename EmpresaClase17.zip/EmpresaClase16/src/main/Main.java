package main;
import util.*;
import model.*;
import java.sql.Date;

public class Main {
  public static void main(String[] args) {

    Listado lista = new Listado();
    lista.addUsuario(new Cliente("benja",new Date(96,11,6), 222222, 9999999,
            "Benjamin andres", "Castro Ormeño", 1231231, "planvital", 2,
            "el alazan", "killpue", 23));
    lista.addUsuario(new Cliente("Carlos",new Date(92,3,12), 222222,
            11111111, "carlos andres", "flores marx",
            1234567, "afp modelo", 1, "salvador", "santiago", 56));
    lista.addUsuario(new Administrativo("Pedro",new Date(90,2,22), 222222,
            "oficina",
            "tengo experiencia"));
    lista.addUsuario(new Profesional("Gonzalo",new Date(93,10,2), 222222,
            "doctorado",
            new Date(96,11,6)));
    lista.addUsuario(new Administrativo("María",new Date(95,7,16), 222222,
            "rrhha", "tengo mucha experiencia en administración"));



    lista.analizarUsuarios();



  }
}