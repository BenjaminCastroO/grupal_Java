package util;

import interfaces.IAsesoria;

import java.util.ArrayList;
import java.util.List;
//Responsabilidad única: esta clase solo se dedica a guardar información del
// listado de usuarios.
public class Listado {
  //Principio abierto y cerrado: en este caso se aplica porque se implementan
  // una interface en vez de implementar la clase específica usuario o las
  // que heredan de ella.
  private List<IAsesoria> listado = new ArrayList<IAsesoria>();

  public void addUsuario(IAsesoria usuario){
    listado.add(usuario);
  }


  //Principio abierto y cerrado: en este caso si se llegara a agregar otro
  // tipo de usuario no sería necesario modificar este bloque de código.

  //Principio de inversión de dependencias: este método no depende del tipo
  // de usuario que esté en la lista. 
  public void analizarUsuarios(){
      for (IAsesoria usuario: listado) {
        usuario.analizarUsuario();
      }
  }
  public Listado() {
  }

  public Listado(List<IAsesoria> listado) {
    this.listado = listado;
  }
}
