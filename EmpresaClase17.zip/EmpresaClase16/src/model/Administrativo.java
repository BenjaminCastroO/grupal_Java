package model;

import java.sql.Date;

//Responsabilidad única: esta clase solo se dedica a guardar información del
// usuario administrativo.
public class Administrativo extends Usuario{
  private String area;
  private String experiencia;

  public Administrativo() {
  }

  public Administrativo(String nombre, Date fechaDeNacimiento, int run, String area, String experiencia) {
    super(nombre, fechaDeNacimiento, run);
    setArea(area);
    setExperiencia(experiencia);
  }

  public String getArea() {
    return area;
  }

  public void setArea(String area) {
    if (!(area.length() >= 5 && area.length() <= 20))
      throw new IllegalArgumentException("El área ingresada debe tener como mínimo 5 " +
                "caracteres y 20 como máximo. Ingrese de nuevo.");
    this.area = area;
  }

  public String getExperiencia() {
    return experiencia;
  }

  public void setExperiencia(String experiencia) {
      if (!( experiencia.length() <= 100))
        throw new IllegalArgumentException("La información ingresada en experiencia debe " +
                "tener como máximo 100 caracteres. Ingrese de nuevo.");
    this.experiencia = experiencia;
  }

  @Override
  public String toString() {
    return "model.Administrativo " +
            "area='" + area + '\'' +
            ", experiencia='" + experiencia + '\'' +
            ' ';
  }
  @Override
  public void analizarUsuario() {
    super.analizarUsuario();
    System.out.println(this.toString());
  }
}
