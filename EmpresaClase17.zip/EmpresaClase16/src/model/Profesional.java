package model;

import java.sql.Date;
//Principio de responsabilidad única: esta clase solo se dedica a guardar
// información de usuario profesional.
public class Profesional extends Usuario{
  private String titulo;
  private Date fechaIngreso;

  public Profesional() {
  }

  public Profesional(String nombre, Date fechaDeNacimiento, int run, String titulo, Date fechaIngreso) {
    super(nombre, fechaDeNacimiento, run);
    this.titulo = titulo;
    this.fechaIngreso = fechaIngreso;
  }

  public String getTitulo() {
    return titulo;
  }

  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }

  public Date getFechaIngreso() {
    return fechaIngreso;
  }

  public void setFechaIngreso(Date fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

  @Override
  public String toString() {
    return "model.Profesional " +
            "titulo='" + titulo + '\'' +
            ", fechaIngreso=" + fechaIngreso +
            ' ';
  }
  @Override
  public void analizarUsuario() {
    super.analizarUsuario();
    System.out.println(this.toString());
  }
}
