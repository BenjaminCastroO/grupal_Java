package model;

import java.sql.Date;
import java.sql.Time;
// Responsabilidad única: esta clase solo se dedica a guardar información de
// accidente.
public class Accidente {
private int idAccidente;
private Date fechaAccidente;
private Time hora;
private String lugar;
private String origen;
private String consecuencia;

  public Accidente() {
  }

  public Accidente(int idAccidente, Date fechaAccidente, Time hora, String lugar, String origen, String consecuencia) {
    this.idAccidente = idAccidente;
    this.fechaAccidente = fechaAccidente;
    this.hora = hora;
    this.lugar = lugar;
    this.origen = origen;
    this.consecuencia = consecuencia;
  }

  public int getIdAccidente() {
    return idAccidente;
  }

  public void setIdAccidente(int idAccidente) {
    this.idAccidente = idAccidente;
  }

  public Date getFechaAccidente() {
    return fechaAccidente;
  }

  public void setFechaAccidente(Date fechaAccidente) {
    this.fechaAccidente = fechaAccidente;
  }

  public Time getHora() {
    return hora;
  }

  public void setHora(Time hora) {
    this.hora = hora;
  }

  public String getLugar() {
    return lugar;
  }

  public void setLugar(String lugar) {
    this.lugar = lugar;
  }

  public String getOrigen() {
    return origen;
  }

  public void setOrigen(String origen) {
    this.origen = origen;
  }

  public String getConsecuencia() {
    return consecuencia;
  }

  public void setConsecuencia(String consecuencia) {
    this.consecuencia = consecuencia;
  }

  @Override
  public String toString() {
    return "model.Accidente{" +
            "idAccidente=" + idAccidente +
            ", fechaAccidente=" + fechaAccidente +
            ", hora=" + hora +
            ", lugar='" + lugar + '\'' +
            ", origen='" + origen + '\'' +
            ", consecuencia='" + consecuencia + '\'' +
            '}';
  }
}
