package model;

import java.sql.Date;
import java.sql.Time;
//Principio de responsabilidad única: esta clase solo se dedica a guardar
// información de la visita en terreno.
public class VisitaEnTerreno {
  private int idVisita;
  private Date fechaVisita;
  private Time horaVisita;
  private String lugarVisita;
  private String comentario;

  public VisitaEnTerreno() {
  }

  public VisitaEnTerreno(int idVisita, Date fechaVisita, Time horaVisita, String lugarVisita, String comentario) {
    this.idVisita = idVisita;
    this.fechaVisita = fechaVisita;
    this.horaVisita = horaVisita;
    this.lugarVisita = lugarVisita;
    this.comentario = comentario;
  }

  public int getIdVisita() {
    return idVisita;
  }

  public void setIdVisita(int idVisita) {
    this.idVisita = idVisita;
  }

  public Date getFechaVisita() {
    return fechaVisita;
  }

  public void setFechaVisita(Date fechaVisita) {
    this.fechaVisita = fechaVisita;
  }

  public Time getHoraVisita() {
    return horaVisita;
  }

  public void setHoraVisita(Time horaVisita) {
    this.horaVisita = horaVisita;
  }

  public String getLugarVisita() {
    return lugarVisita;
  }

  public void setLugarVisita(String lugarVisita) {
    this.lugarVisita = lugarVisita;
  }

  public String getComentario() {
    return comentario;
  }

  public void setComentario(String comentario) {
    this.comentario = comentario;
  }

  @Override
  public String toString() {
    return "model.VisitaEnTerreno{" +
            "idVisita=" + idVisita +
            ", fechaAccidente=" + fechaVisita +
            ", hora=" + horaVisita +
            ", lugar='" + lugarVisita + '\'' +
            ", comentario='" + comentario + '\'' +
            '}';
  }
}
