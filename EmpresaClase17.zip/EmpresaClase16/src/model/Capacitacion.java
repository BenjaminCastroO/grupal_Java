package model;

import java.sql.Date;
import java.sql.Time;
import java.util.Scanner;
//Responsabilidad única: esta clase solo se dedica a guardar información de
// la capacitación.
public class Capacitacion {
  private Cliente cliente;
  private int idInterno;
  private int rut;
  private String dia;
  private String hora;
  private String lugar;
  private int duracion;
  private int cantAsistentes;

  public Capacitacion() {
  }

  public Capacitacion(Cliente cliente, int idInterno, int rut, String dia,
                      String hora, String lugar, int duracion, int cantAsistentes) {
    this.cliente = cliente;
    setIdInterno(idInterno);
    this.rut = rut;
    setDia(dia);
    this.hora = hora;
    setLugar(lugar);
    this.duracion = duracion;
    this.cantAsistentes = cantAsistentes;
  }

  public String mostrarDetalle(){
    String mensaje = "La capacitación será en " + lugar + " a las " + hora  +
            " del día " + dia + " y durará " + duracion + " minutos.";
    return mensaje;
  }

  public double getIdInterno() {
    return idInterno;
  }

  public void setIdInterno(int idInterno) {
      if (idInterno == 0)
       throw new IllegalArgumentException("El id interno de  la capacitación debe ser distinto" +
               " de cero. Ingrese nuevamente.");
    this.idInterno = idInterno;
  }

  public String getDia() {
    return dia;
  }

  public void setDia(String dia) {
    if(!(dia.equalsIgnoreCase("lunes") || dia.equalsIgnoreCase("martes") ||
            dia.equalsIgnoreCase("miercoles") || dia.equalsIgnoreCase("jueves") ||
            dia.equalsIgnoreCase("viernes") || dia.equalsIgnoreCase("sabado") ||
            dia.equalsIgnoreCase("domingo")))
      throw new IllegalArgumentException("Ingrese un día de la semana válido,"
      + " (lunes, martes, miercoles, jueves, viernes, sabado, domingo).");
    this.dia = dia;
  }

  public String getHora() {
    return hora;
  }

  public void setHora(String hora) {
    this.hora = hora;
  }

  public String getLugar() {
    return lugar;
  }

  public void setLugar(String lugar) {
    if (!(lugar.length() >= 10 && lugar.length() <= 50))
      throw new IllegalArgumentException("El lugar ingresado debe tener " +
              "como mínimo 10 caracteres y 50 como máximo. Ingrese de nuevo.");
    this.lugar = lugar;
  }

  public int getDuracion() {
    return duracion;
  }

  public void setDuracion(int duracion) {
    if (!(duracion >= 5 && duracion <= 20))
      throw new IllegalArgumentException("La duración ingresada debe tener " +
              "como mínimo 5 " +
              "caracteres y 20 como máximo. Ingrese de nuevo.");
    this.duracion = duracion;
  }

  public int getCantAsistentes() {
    return cantAsistentes;
  }

  public void setCantAsistentes(int cantAsistentes) {
    this.cantAsistentes = cantAsistentes;
  }

  public Cliente getCliente() {
    return cliente;
  }

  public void setCliente(Cliente cliente) {
    this.cliente = cliente;
  }

  public int getRut() {
    return rut;
  }

  public void setRut(int rut) {
    this.rut = rut;
  }

  @Override
  public String toString() {
    return "Capacitacion{" +
            "cliente=" + cliente +
            ", idInterno=" + idInterno +
            ", rut=" + rut +
            ", dia='" + dia + '\'' +
            ", hora='" + hora + '\'' +
            ", lugar='" + lugar + '\'' +
            ", duracion=" + duracion +
            ", cantAsistentes=" + cantAsistentes +
            '}';
  }
}