import java.sql.Date;

public class Main {
  public static void main(String[] args) {

    // crear 2 instancias de cada clase

    Cliente cliente1 = new Cliente(9999999, "Benjamin andres", "Castro Ormeño",
            1231231, 2, "el alazan", "killpue", 23);
    Cliente cliente2 = new Cliente(11111111, "carlos andres", "flores marx",
            1234567, 1, "salvador", "santiago", 56);

    Capacitacion capacitacion1 = new Capacitacion(144.0 , 9191911,
            new Date(112,5,21),
            "12:00", "casa", 2, 22);
    Capacitacion capacitacion2 = new Capacitacion(166.0 , 7171711,
            new Date(110,6,21),
            "15:00", "oficina", 4, 20);

    // desplegar objetos metodo toString()

    System.out.println(cliente1.toString());
    System.out.println(cliente2.toString());
    System.out.println(capacitacion1.toString());
    System.out.println(capacitacion2.toString());

    // modificar atributo de cada clase

    cliente1.setTelefono(1445698);
    capacitacion1.setLugar("salon1");


    // desplegar datos de cada objeto con metodos accesores

    System.out.println("Datos de Cliente 1:");
    System.out.println("Nombre: " + cliente1.getNombres());
    System.out.println("Teléfono: " + cliente1.getTelefono());
    System.out.println("Sistema de Salud: " + cliente1.obtenerSistemaSalud());
    System.out.println("Dirección: " + cliente1.getDireccion());
    System.out.println("Comuna: " + cliente1.getComuna());
    System.out.println("Edad: " + cliente1.getEdad());
    System.out.println("Sistema de Salud válido: " + cliente1.comprobarSistemaDeSalud(cliente1.getSistemaDeSalud()));
    System.out.println("RUT válido: " + cliente1.comprobarRut(cliente1.getRut()));

    System.out.println();

    System.out.println("Datos Capacitacion 1");
    System.out.println("Id Interno: " + capacitacion1.getIdInterno());
    System.out.println("RUT: " + capacitacion1.getRut());
    System.out.println("Dia: " + capacitacion1.getDia());
    System.out.println("Hora: " + capacitacion1.getHora());
    System.out.println("Lugar: " + capacitacion1.getDuracion());
    System.out.println("Duracion: " + capacitacion1.getDuracion());
    System.out.println("Cantidad Asistentes: " + capacitacion1.getCantAsistentes());

    System.out.println();

    System.out.println("Datos de Cliente 2:");
    System.out.println("Nombre: " + cliente2.getNombres());
    System.out.println("Teléfono: " + cliente2.getTelefono());
    System.out.println("Sistema de Salud: " + cliente2.obtenerSistemaSalud());
    System.out.println("Dirección: " + cliente2.getDireccion());
    System.out.println("Comuna: " + cliente2.getComuna());
    System.out.println("Edad: " + cliente2.getEdad());
    System.out.println("Sistema de Salud válido: " + cliente2.comprobarSistemaDeSalud(cliente2.getSistemaDeSalud()));
    System.out.println("RUT válido: " + cliente2.comprobarRut(cliente2.getRut()));

    System.out.println();

    System.out.println("Datos Capacitacion 2");
    System.out.println("Id Interno: " + capacitacion2.getIdInterno());
    System.out.println("RUT: " + capacitacion2.getRut());
    System.out.println("Dia: " + capacitacion2.getDia());
    System.out.println("Hora: " + capacitacion2.getHora());
    System.out.println("Lugar: " + capacitacion2.getDuracion());
    System.out.println("Duracion: " + capacitacion2.getDuracion());
    System.out.println("Cantidad Asistentes: " + capacitacion2.getCantAsistentes());

  }
}