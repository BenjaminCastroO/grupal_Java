import java.sql.Date;
import java.time.LocalDate;

public class Usuario {
  private String nombre;
  private Date fechaDeNacimiento;
  private int run;

  public Usuario() {
  }

  public Usuario(String nombre, Date fechaDeNacimiento, int run) {
    this.nombre = nombre;
    this.fechaDeNacimiento = fechaDeNacimiento;
    this.run = run;
  }

  public String mostrarEdad(){
    int edad = calcularEdad();
    return ("El usuario tiene " + edad + " años.");
  }
  private int calcularEdad(){
    return LocalDate.now().getYear() - fechaDeNacimiento.getYear() - 1900;
  }
  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public Date getFechaDeNacimiento() {
    return fechaDeNacimiento;
  }

  public void setFechaDeNacimiento(Date fechaDeNacimiento) {
    this.fechaDeNacimiento = fechaDeNacimiento;
  }

  public int getRun() {
    return run;
  }

  public void setRun(int run) {
    this.run = run;
  }

  @Override
  public String toString() {
    return "Usuario{" +
            "nombre='" + nombre + '\'' +
            ", fechaDeNacimiento=" + fechaDeNacimiento +
            ", run=" + run +
            '}';
  }
}
